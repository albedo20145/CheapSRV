import React from 'react';
import { Link, useLocation } from 'wouter';
import { Home, Search, User, Layers } from 'lucide-react';
import { motion } from 'framer-motion';

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { icon: Home, label: 'Home', path: '/home' },
    { icon: Search, label: 'Explore', path: '/explore' },
    { icon: Layers, label: 'Categories', path: '/categories' },
    { icon: User, label: 'Profile', path: '/profile' },
  ];

  if (location === '/' || location === '/onboarding' || location === '/auth') return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-slate-900/90 backdrop-blur-lg border-t border-slate-800 pb-safe pt-2 px-6 z-50">
      <div className="flex justify-between items-center max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = location === item.path || (item.path === '/explore' && location.startsWith('/category'));
          
          return (
            <Link key={item.path} href={item.path}>
              <div className={`flex flex-col items-center space-y-1 p-2 cursor-pointer transition-colors duration-200 ${isActive ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'}`}>
                <motion.div
                  whileTap={{ scale: 0.8 }}
                  animate={isActive ? { 
                    scale: 1.1,
                    y: -4,
                    color: '#22d3ee'
                  } : { 
                    scale: 1, 
                    y: 0,
                    color: '#94a3b8'
                  }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                >
                  <item.icon size={24} strokeWidth={isActive ? 2.5 : 2} />
                </motion.div>
                <span className="text-[10px] font-medium">{item.label}</span>
                {isActive && (
                  <motion.div 
                    layoutId="nav-indicator"
                    className="absolute bottom-1 w-1 h-1 bg-cyan-400 rounded-full shadow-[0_0_8px_rgba(34,211,238,0.8)]"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
