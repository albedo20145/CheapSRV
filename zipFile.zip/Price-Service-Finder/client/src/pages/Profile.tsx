import React from 'react';
import { useLocation, Link } from 'wouter';
import { motion } from 'framer-motion';
import { User, Settings, Heart, LogOut, ChevronRight, Shield, FileText } from 'lucide-react';
import { useStore } from '@/lib/store';
import { services } from '@/data/db';
import { ServiceCard } from '@/components/ServiceCard';
import { PageTransition, staggerContainer, staggerItem } from '@/components/layout/PageTransition';

export default function Profile() {
  const { bookmarks, logout } = useStore();
  const [, setLocation] = useLocation();

  const bookmarkedItems = services.filter(s => bookmarks.includes(s.id));

  const handleLogout = () => {
    logout();
    setLocation('/auth');
  };

  return (
    <PageTransition>
      <div className="min-h-screen bg-[#0f172a] pb-24">
        <div className="p-6 pt-12 flex items-center gap-4 mb-6">
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
            className="w-20 h-20 rounded-full bg-gradient-to-br from-cyan-400 to-blue-600 p-[2px]"
          >
            <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center">
               <User size={32} className="text-white" />
            </div>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h1 className="text-2xl font-bold text-white font-display">Guest User</h1>
            <p className="text-slate-400 text-sm">Free Plan</p>
          </motion.div>
        </div>

        <motion.div 
          className="px-6 space-y-8"
          variants={staggerContainer}
          initial="hidden"
          animate="show"
        >
          {/* Bookmarks */}
          <motion.section variants={staggerItem}>
            <div className="flex items-center gap-2 mb-4">
              <Heart size={18} className="text-rose-500" fill="currentColor" />
              <h2 className="text-lg font-bold text-white">Saved Items</h2>
            </div>
            
            {bookmarkedItems.length > 0 ? (
              <div className="space-y-4">
                {bookmarkedItems.map(item => (
                  <ServiceCard key={item.id} item={item} />
                ))}
              </div>
            ) : (
              <div className="p-8 text-center bg-slate-800/30 rounded-2xl border border-slate-700/50 border-dashed">
                <p className="text-slate-500 text-sm">No saved items yet.</p>
              </div>
            )}
          </motion.section>

          {/* Settings */}
          <motion.section variants={staggerItem} className="space-y-3">
            <h2 className="text-lg font-bold text-white mb-4">Settings</h2>
            
            <Link href="/settings">
              <motion.button 
                whileTap={{ scale: 0.98 }}
                className="w-full flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-slate-700 hover:bg-slate-800 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Settings size={20} className="text-slate-400" />
                  <span className="text-slate-200">App Preferences</span>
                </div>
                <ChevronRight size={18} className="text-slate-500" />
              </motion.button>
            </Link>

            <Link href="/legal/privacy">
              <motion.button 
                whileTap={{ scale: 0.98 }}
                className="w-full flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-slate-700 hover:bg-slate-800 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Shield size={20} className="text-slate-400" />
                  <span className="text-slate-200">Privacy Policy</span>
                </div>
                <ChevronRight size={18} className="text-slate-500" />
              </motion.button>
            </Link>

            <Link href="/legal/terms">
              <motion.button 
                whileTap={{ scale: 0.98 }}
                className="w-full flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-slate-700 hover:bg-slate-800 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <FileText size={20} className="text-slate-400" />
                  <span className="text-slate-200">Terms of Service</span>
                </div>
                <ChevronRight size={18} className="text-slate-500" />
              </motion.button>
            </Link>

            <motion.button 
              whileTap={{ scale: 0.98 }}
              onClick={handleLogout}
              className="w-full flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-slate-700 hover:bg-rose-900/20 hover:border-rose-900/50 hover:text-rose-400 transition-colors mt-8 group"
            >
              <div className="flex items-center gap-3">
                <LogOut size={20} className="text-slate-400 group-hover:text-rose-400" />
                <span className="text-slate-200 group-hover:text-rose-400">Log Out</span>
              </div>
            </motion.button>
          </motion.section>

          <div className="text-center text-slate-600 text-xs pb-8">
            CheapSRV v1.0.0
          </div>
        </motion.div>
      </div>
    </PageTransition>
  );
}
