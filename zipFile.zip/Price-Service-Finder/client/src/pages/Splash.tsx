import React, { useEffect } from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import logo from '@assets/generated_images/neon_cyan_abstract_geometric_logo_on_dark_blue.png';

export default function Splash() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    const timer = setTimeout(() => {
      // Check if user has seen onboarding in real app, for now just go to onboarding
      setLocation('/onboarding');
    }, 2500);
    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <div className="h-screen w-full bg-[#0f172a] flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-cyan-500/20 rounded-full blur-3xl animate-pulse" />

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative z-10 flex flex-col items-center"
      >
        <img src={logo} alt="CheapSRV Logo" className="w-32 h-32 rounded-2xl shadow-2xl shadow-cyan-500/20 mb-6" />
        <h1 className="text-4xl font-bold font-display text-white tracking-tight">
          Cheap<span className="text-cyan-400">SRV</span>
        </h1>
        <p className="text-slate-400 mt-2 font-mono text-xs tracking-widest uppercase">Price & Service Finder</p>
      </motion.div>

      <div className="absolute bottom-10 text-slate-600 text-[10px] font-mono">
        v1.0.0 • Secure & Safe
      </div>
    </div>
  );
}
